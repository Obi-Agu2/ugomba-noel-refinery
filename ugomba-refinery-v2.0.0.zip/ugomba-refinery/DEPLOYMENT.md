# 🚀 Deployment Guide — Ugomba Noel Refinery Platform

## Fastest Deployment (2 minutes)

### Netlify Drop
1. Go to https://app.netlify.com/drop
2. Drag the `index.html` file onto the page
3. Your app is live at a Netlify URL instantly
4. Optional: Set a custom domain in Netlify settings

### GitHub Pages
1. Create a new GitHub repository
2. Upload `index.html` as the only file
3. Go to Settings → Pages → Source: Deploy from branch → main → / (root)
4. Your app will be live at `https://yourusername.github.io/repo-name/`

---

## Production Considerations

Before deploying for real production use:

### Security
- [ ] Replace localStorage with a proper database (Supabase / Firebase / PocketBase)
- [ ] Implement proper password hashing (bcrypt)
- [ ] Add HTTPS (automatic on Netlify/Vercel/GitHub Pages)
- [ ] Remove demo quick-login buttons from LoginPage
- [ ] Change all default passwords immediately

### Data
- [ ] Back up localStorage data regularly (or migrate to a database)
- [ ] Set up automatic inventory alerts via email
- [ ] Configure PDF export for NAFDAC reports

### Users
- [ ] Create accounts for all staff before go-live
- [ ] Assign correct positions and custom roles
- [ ] Test access control with each user type
- [ ] Brief staff on their login credentials

---

## Environment-Specific Notes

### Nigerian Connectivity
The app loads two external resources:
- Google Fonts (IBM Plex Sans/Mono) — degrades gracefully to system fonts if blocked
- React/Babel from unpkg.com CDN — required for the app to work

If internet connectivity is unreliable, download these files and host them locally:
```html
<!-- Replace CDN links with local files: -->
<script src="./lib/react.production.min.js"></script>
<script src="./lib/react-dom.production.min.js"></script>
<script src="./lib/babel.min.js"></script>
```

Download from:
- https://unpkg.com/react@18/umd/react.production.min.js
- https://unpkg.com/react-dom@18/umd/react-dom.production.min.js
- https://unpkg.com/@babel/standalone/babel.min.js

### Offline Use
For full offline capability, save the page with all resources embedded using a tool like `wget`:
```bash
wget --page-requisites --convert-links index.html
```

---

## Support

For technical issues, contact your platform administrator.
Platform built April 2026 for Ugomba Noel Vegetable Oil Refinery operations.
