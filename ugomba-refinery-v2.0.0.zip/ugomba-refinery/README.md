# ⬡ Ugomba Noel — Vegetable Oil Refinery Operations Platform
## v2.0.0 — Full Deployable Build

---

## 🚀 Quick Start

This is a **single-file, zero-dependency** web application.

```
Open index.html in any modern browser.
```

No build step. No server required. No npm install.

---

## 🔐 Default Login Credentials

| User | Email | Password | Role | Access Level |
|------|-------|----------|------|-------------|
| Super Administrator | superadmin@ugomba.com | super123 | superadmin | Full system control |
| Admin (CEO) | admin@ugomba.com | admin123 | admin | Full operations |
| Production Manager | manager@ugomba.com | mgr123 | user (Manager) | Approvals, reports |
| Lab Technician | lab@ugomba.com | lab123 | user (Lab Tech) | Calculators only |
| Secretary | secretary@ugomba.com | sec123 | user (Secretary) | NAFDAC reports only |

> **Important:** Change all passwords immediately after first login in production.

---

## 🏗️ Architecture

### Technology Stack
- **Frontend:** React 18 (via CDN) + Vanilla CSS
- **Storage:** localStorage (browser-based persistence)
- **Auth:** Session-based (stored in localStorage)
- **Fonts:** IBM Plex Sans + IBM Plex Mono (Google Fonts)

### File Structure
```
ugomba-refinery/
├── index.html          ← Complete application (single file)
├── README.md           ← This file
├── DEPLOYMENT.md       ← Deployment guide
└── CHANGELOG.md        ← Version history
```

---

## 🔐 Access Control System

### Two-Layer Security

#### Layer 1: System Role (hard-coded)
```
superadmin  → Full platform control, user deletion, role override
admin       → Full operational access (CEO level)
user        → Governed by position + custom_role
```

#### Layer 2: Position Hierarchy
```
SuperAdmin (7) > CEO (6) > Director (5) > Manager (4) >
Supervisor (3) > Lab Technician (2) > Secretary (1)
```

#### Layer 3: Custom Role Permissions (database-driven)
| Permission | full_access | manager_role | lab_tech_role | secretary_role |
|------------|:-----------:|:------------:|:-------------:|:--------------:|
| NaOH Calculator | ✓ | ✓ | ✓ | ✗ |
| Phosphoric Calc | ✓ | ✓ | ✓ | ✗ |
| Vitamin A Calc | ✓ | ✓ | ✓ | ✗ |
| Cost Dashboard | ✓ | ✓ | ✗ | ✗ |
| Analytics | ✓ | ✓ | ✗ | ✗ |
| NAFDAC Report | ✓ | ✓ | ✗ | ✓ |
| Inventory Mgmt | ✓ | ✓ | ✗ | ✗ |
| Audit Log | ✓ | ✓ | ✗ | ✗ |
| Delete Batches | ✓ | ✗ | ✗ | ✗ |
| Role Management | ✓ | ✗ | ✗ | ✗ |
| Inflation Settings | ✓ | ✗ | ✗ | ✗ |

**Rule:** `superadmin` and `admin` bypass ALL permission checks.

---

## 📋 Modules

### 🧪 Chemical Calculators

#### NaOH (Caustic Soda) Calculator
- Formula: NaOH = (Volume × FFA% × 0.142 × OilFactor) / 1000
- Includes 15% excess for complete neutralisation
- Lye solution preparation parameters (16% w/v)
- Supports: Palm, Soybean, Sunflower, Groundnut, Canola oils
- Outputs: NaOH kg, water volume, lye solution volume, temperature, mixing time

#### Phosphoric Acid Degumming Calculator
- Dosage based on iron content (ppm) and oil volume
- Dilution parameters from 85% concentrate
- Outputs: H₃PO₄ volume, diluted acid volume, water, contact time, temperature

#### Vitamin A Fortification Calculator
- NAFDAC minimum: 11 IU/g (enforced — submission blocked if below minimum)
- Inputs: oil volume, target concentration, stock concentrate potency
- Outputs: theoretical dose, +10% excess, total IU, compliance status

### 🔄 Batch Approval Workflow
1. Lab Tech runs calculation → submits for approval
2. Batch enters Approval Queue with status: **pending**
3. Manager+ approves or rejects with reason
4. On approval: inventory auto-deducted, batch status → **approved**
5. On rejection: reason stored, no inventory change

### 💰 Cost Analysis Dashboard
- Real-time cost breakdown (materials, chemicals, labour, energy, packaging)
- Inflation-adjusted pricing chain (ex-factory → wholesale → retail)
- CEO/Director-controlled margin formula: `inflation_rate + margin_above_inflation`
- Total batch profit calculation

### 📦 Inventory Management
- 6 pre-seeded chemicals with stock levels
- Low-stock alerts (sidebar badge + topbar notification)
- Stock adjustment with audit trail
- Add new chemicals with category, supplier, unit cost
- Total inventory value calculation

### 📊 Analytics Dashboard
- Operational KPIs: total oil processed, approval rate, batch counts
- Batch type distribution with progress bars
- Inventory health monitoring
- Composite operational health score

### 📄 NAFDAC Compliance Report
- Printable compliance report for regulatory submission
- Vitamin A compliance tracking (≥11 IU/g minimum)
- All approved batch records
- Official declaration section

### 📝 Audit Log
- Automatic logging of all key actions
- Categories: batch, approval, inventory, auth, system
- Filter by category
- Last 200 entries retained

### 👥 Role & User Management
- Create, edit, activate/deactivate users
- Assign system role, position, and custom permissions
- Permission matrix view
- SuperAdmin-only: delete users

---

## 💾 Data Persistence

All data is saved to **browser localStorage** under the prefix `unr_`:
- `unr_session` — active user session
- `unr_users` — user accounts
- `unr_batches` — batch records
- `unr_inventory` — chemical stock levels
- `unr_audit` — audit log
- `unr_inflation` — inflation rate setting
- `unr_margin` — margin setting

> To reset to factory defaults, open browser DevTools → Application → Local Storage → delete all `unr_*` keys, then refresh.

---

## 🌐 Deployment Options

### Option 1: Static File Hosting (Recommended)
Upload `index.html` to any static host:
- **Netlify:** Drag & drop at app.netlify.com/drop
- **GitHub Pages:** Push to `/docs` folder, enable Pages
- **Vercel:** `vercel --prod` in the folder
- **Any web server:** Just serve the HTML file

### Option 2: Production with Real Backend
To scale to a production backend, replace the `LS` (localStorage) functions with API calls:

```javascript
// Replace LS.get / LS.set with your API:
const API_BASE = 'https://your-api.com';

const getUsers = () => fetch(`${API_BASE}/users`).then(r=>r.json());
const saveBatch = (batch) => fetch(`${API_BASE}/batches`, {method:'POST', body:JSON.stringify(batch)});
```

Recommended backends:
- **Supabase** (PostgreSQL + Auth, free tier)
- **Firebase** (Firestore, free tier)
- **PocketBase** (self-hosted, single binary)

### Option 3: Desktop App (Electron)
Wrap in Electron for a native desktop app:
```bash
npm install -g electron
electron index.html
```

---

## 🔧 Customisation

### Add New Oil Types
In the `OIL_FACTORS` constant:
```javascript
const OIL_FACTORS = {
  'Palm Oil': 1.0,
  'Your Oil': 0.95,  // Add here
};
```

### Add New Chemical Categories
In the inventory add form's category list:
```html
<option>Your Category</option>
```

### Adjust NAFDAC Minimum
Search for `11` in the VitaminACalc component — change the compliance threshold as needed.

### Modify Permission Roles
In the `DEFAULT_PERMISSIONS` object, add/remove permission keys.

---

## 📝 Known Limitations (localStorage version)

1. **Single-device only** — data does not sync across devices
2. **No email notifications** — approval alerts require backend integration
3. **No file export** — CSV/PDF export requires a backend or print-to-PDF
4. **Session expires on clear** — clearing browser data logs users out
5. **No real password hashing** — passwords stored in plain text in localStorage

For production use, implement a proper backend with hashed passwords and a database.

---

## 📋 Changelog

### v2.0.0 (April 2026)
- Full rebuild as standalone deployable application
- Added SuperAdmin role with user deletion and full override
- localStorage persistence for all data
- Modal-based user editing
- Tab navigation in Approval Queue and Role Management
- Inventory value calculation
- NAFDAC print button
- Responsive design for mobile

### v1.0.0 (Base44 version)
- Original Base44 platform build
- React + Tailwind CSS
- Base44 SDK for auth and database
